<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = 'josenha';
    $dbName = 'dbjjfilmes';

    $conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
?>

